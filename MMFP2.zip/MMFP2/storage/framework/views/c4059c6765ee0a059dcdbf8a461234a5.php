<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>MFM CapetownChurch</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="/css/style.css">
</head>
<body>

<header class="top-bar">
    <div class="logo">⛪ Grace Church</div>

    <nav>
        <a href="/">Home</a>
        <a href="/about">About</a>
        <a href="/services">Services</a>
        <a href="/contact">Contact</a>
    </nav>
</header>

<main>
    <?php echo $__env->yieldContent('content'); ?>
</main>

<footer>
    <p>© <?php echo e(date('Y')); ?> MFM Capetown Church. All rights reserved.</p>
</footer>

</body>
</html><?php /**PATH C:\xampp\htdocs\WEBSITES\mfmcapetown\resources\views/welcome.blade.php ENDPATH**/ ?>