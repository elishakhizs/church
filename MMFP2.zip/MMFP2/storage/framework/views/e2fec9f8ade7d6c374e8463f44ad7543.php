<?php echo app('Illuminate\Foundation\Vite')(entrypoints: 'resources/css/app.css'); ?>
<?php echo app('Illuminate\Foundation\Vite')(entrypoints: 'resources/js/app.js'); ?>
<?php echo app('Illuminate\Foundation\Vite')(entrypoints: 'resources/css/about.css'); ?>


<?php $__env->startSection('content'); ?>
    <section class="Mission">
        <h1>MISSION AND VISION</h1>
    </section>
    <section class="words">
        <p>
            MFM Ministries is a full gospel ministry devoted to the Revival of Apostolic Signs, 
            Holy Ghost fireworks and the unlimited demonstration of the power of God to deliver to the uttermost. 
            Absolute holiness within and without as the greatest spiritual insecticide and a pre-requisite for 
            Heaven is taught openly. MFM is a do-it-yourself Gospel ministry where your hands are trained to wage 
            war and your fingers to do battle. At MFM, aggressive prayer is considered as an aid to spiritual focus 
            and a check against being overwhelmed by the flesh. At MFM Prayer City, prayer goes on 24 hours a day, 
            7 days a week, non-stop.<br><br>

            The objectives of this ministry are:
       </p>
            <li>To propagate the gospel of our Lord Jesus Christ all over the world</li>
            <li>To promote the revival of Apostolic signs, wonders and miracles</li>
            <li>To bring together children of God who are lost in dead churches</li>
            <li>To train believers in the art and science of spiritual warfare; thus making them an aggressive and victorious army for the Lord</li>
            <li>To train believers to receive Holy Ghost baptism and fire as well as a daily walk and relationship with the Holy Spirit</li>
            <li>To turn the joy of our enemies to sorrow. That is why we would always have a Deliverance ministry wherever we are. If you do not believe in deliverance, 
                you are not supposed to be in MFM
            </li>
            <li>To build an aggressive end-time army for the Lord. MFM is an end-time church where we build an aggressive end-time army for the Lord.
                An end-time church is a church where a sinner enters with two options: he either repents or does not come back, contrary to the present 
                day church where sinners are comfortable and find things so easy and convenient
            </li>
            <li>To deliver those who have become slaves to pastors, prophets and apostles</li>
            <li>To build up heavenly-bound and aggressive Christians. The priority in MFM is for people to make heaven. It is not a worldly Church</li>
            <li>To build up prayer eagles</li>
            <li>To purify the Pentecostal dirtiness of this age</li>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.Default', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\WEBSITES\mfmcapetown\resources\views/about.blade.php ENDPATH**/ ?>