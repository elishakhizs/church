<?php echo app('Illuminate\Foundation\Vite')(entrypoints: 'resources/css/app.css'); ?>
<?php echo app('Illuminate\Foundation\Vite')(entrypoints: 'resources/js/app.js'); ?>
<?php echo app('Illuminate\Foundation\Vite')(entrypoints: 'resources/css/about.css'); ?>


<?php $__env->startSection('content'); ?>
    <section class="givess">
        <h1>TITHE AND OFFERING </h1>
    </section>
      <div>
        <center><br><p style=" color:white"> GIVE</p> 
               <h3> Pay your offerings, tithes, first fruit offering etc via any of the listed platforms.
               </h3>
        </center>
      </div><br>
      <center>
        <a href="https://www.paypal.com/donate/?hosted_button_id=43MMV55U66DZQ">
            <img src="images/pay.jpg" width="400"hight="400" class="paypal">
        </a><br><br>
        <a href="https://www.paypal.com/donate/?hosted_button_id=43MMV55U66DZQ" class="button">Pay Here</a><br><br><br>
      </center>
    
    
     
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Default', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\WEBSITES\mfmcapetown\resources\views/Give.blade.php ENDPATH**/ ?>