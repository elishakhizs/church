<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>MFM Capetown</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="/css/style.css">
    <link rel="shortcut icon" type="image/x-icon" href="icon.ico" />
</head>
<body>

<header class="top-bar transparent" id="navbar">
    <div class="logo"><a href="http://localhost/WEBSITES/mfmcapetown/public"><img src="images/church.png" width="60" height="60"></a>
    MFM CAPETOWN</div>

    <nav class="nav-links">
        <a href="http://localhost/WEBSITES/mfmcapetown/public">Home</a>
        <a href="<?php echo e(route("about")); ?>">About</a>
        <a href="<?php echo e(route("live")); ?>">Live</a>
        <a href="<?php echo e(route('Give')); ?>" class="btns">GIVE</a>
    </nav>

    <div class="hamburger" id="hamburger">
            <span></span>
            <span></span>
            <span></span>
    </div>

    <!-- Mobile Navigation -->
    <nav class="mobile-nav" id="mobileNav">
        <a href="/">home</a>
        <a href="<?php echo e(route("about")); ?>">About</a>
        <a href="<?php echo e(route("live")); ?>">Live</a>
        <a href="<?php echo e(route('Give')); ?>">GIVE</a>
    </nav>
</header>


<main>
    <?php echo $__env->yieldContent('content'); ?>
</main>

<footer class="site-footer">
    <div class="footer-container">

        <!-- NAVIGATION -->
        <div class="footer-section">
            <h4>Navigation</h4>
            <ul>
                <li><a href="/">home</a></li>
                <li><a href="<?php echo e(route("about")); ?>">About</a></li>
                <li><a href="<?php echo e(route("live")); ?>">Live</a></li>
                <li><a href="<?php echo e(route('Give')); ?>">GIVE</a></li>
            </ul>
        </div>

        <!-- CONTACT -->
        <div class="footer-section">
            <h4>Contact</h4>
            <p>+27 67 664 0827</p>
            <p>info@mfm-capetown.co.za</p>
            <p>36 Enterprise Way, Riversgate, Sandown Road, Cape Town</p>
        </div>

        <!-- SOCIALS -->
        <div class="footer-section">
            <h4>Follow Us</h4>
            <div class="social-icons">
                <a href="https://www.facebook.com/share/1KTdKmqZcM/?mibextid=wwXIfr"><img src="images/Facebook.png"></a>
                <a href="https://www.instagram.com/mfm_capetown?igsh=MTAweHV3ajM2d3d5Ng=="><img src="images/instagram.png"></a>
                <a href="https://youtube.com/@mfmcapetown838?si=QfrAbScOFufefaZq"><img src="images/youtube.png"></a>
                <a href="#"><img src="images/whatapp.png"></a>
            </div>
        </div>

        <!-- BOOK -->
        <div class="footer-section">
            <h4>Book</h4>
            <a href="/book" class="footer-btn">Book Now</a>
        </div>
    </div>
</footer>
<footer>
    <div class="FinalFooter">
           <center><p>© <?php echo e(date('Y')); ?> MFM Capetown Church. All rights reserved.</p></center>
           <center><p><a href="https://heflexitservice.co.za">Designed by HEFLEX Designers </a> </p></center> 
    </div>
</footer>


<script>
    window.addEventListener('scroll', function () {
        const navbar = document.getElementById('navbar');

        if (window.scrollY > 80) {
            navbar.classList.remove('transparent');
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
            navbar.classList.add('transparent');
        }
    });
</script>

<script>
    const hamburger = document.getElementById('hamburger');
    const mobileNav = document.getElementById('mobileNav');

    hamburger.addEventListener('click', () => {
        mobileNav.classList.toggle('show');
    });
</script>

</body>
</html><?php /**PATH C:\xampp\htdocs\WEBSITES\mfmcapetown\resources\views/layouts/Default.blade.php ENDPATH**/ ?>