<?php echo app('Illuminate\Foundation\Vite')(entrypoints: 'resources/css/app.css'); ?>
<?php echo app('Illuminate\Foundation\Vite')(entrypoints: 'resources/js/app.js'); ?>
<?php echo app('Illuminate\Foundation\Vite')(entrypoints: 'resources/css/services.css'); ?>


<?php $__env->startSection('content'); ?>
<section class="hero"><br><br><br>
  <div class="heroo">
    <h1>WELCOME TO MOUNTAIN OF FIRE AND MIRACLE<br>MINISTRIES SOUTH-AFRICA CAPE-TOWN</h1>
    <p>Surely the Lord is in this place </p>
    <a href="#video" class="btn">Join Us</a>
  </div>
</section>

<br>
<section class="info">
    <div class="service-row animate-card">
        <div class="service-card">
           <h2>Sunday Service</h2>
           <p>Every Sunday at 09:00 AM</p><br>
           <p>You are welcome to join our live service for a refreshing time 
           in God's presences every Sunday </p>
        </div>
      <div class="gradient-box">
           <div class="gradient-content">
               <div class="gradient-icon">📖</div>
                   <p class="scripture">
                     “For where two or three gather in my name, there am I with them.”
                  </p>
                 <span class="verse">Matthew 18:20</span>
               </div>
            </div>
       </div>
    </div>

    <div class="service-row animate-card">
        <div class="service-card">
            <h2>Monday Bible Study</h2>
            <p>Every Monday at 18:00 PM</p>
            <p>Come join us in digging deep with our Lord Jesus Christ as we read
                and understand the word of God
            </p>
        </div>
        <div class="gradient-box">
           <div class="gradient-content">
               <div class="gradient-icon">📖</div>
                   <p class="scripture">
                     “Join us to become a Kingdom builder. Expect grat things from God; attempt great things for God”
                  </p>
                 <span class="verse">Matthew 16:18</span>
               </div>
            </div>
       </div>
    </div>

    <div  class="service-row animate-card">
        <div class="service-card">
            <h2>Wednessday Prayer Meetings</h2>
            <p>Every Wednesdays at 17:30 PM</p>
            <p>Join us as we connect to our father in the lord every wednesday 
                for divine power packed Manna Water Service
            </p>
        </div>
        <div class="gradient-box">
           <div class="gradient-content">
               <div class="gradient-icon">📖</div>
                   <p class="scripture">
                     “Week End Deliverance takes place Quarterly.Last Week end of the month”
                  </p>
                 <span class="verse">Obadiah 1:17</span>
               </div>
            </div>
       </div>
    </div>

    <div  class="service-row animate-card">
        <div class="service-card">
            <h2>Power Must Change Hands</h2>
            <p>Every First Saturday at 8:00 AM</p>
            <p>Every first saturday of the month is our power must change hand program
              live from Nigeria
            </p>
        </div>

        <div class="gradient-box">
           <div class="gradient-content">
               <div class="gradient-icon">📖</div>
                   <p class="scripture">
                    Coming Soon “UNJUSTIFIED PRAISE.” Date 27th March 2026 Time (10pm).
                  </p>
                 <span class="verse">Acts 16:25</span>
               </div>
            </div>
       </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function () {
        const cards = document.querySelectorAll('.animate-card');

        const observer = new IntersectionObserver(entries => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('show');
                    observer.unobserve(entry.target); // animate once
                }
            });
        }, {
            threshold: 0.2
        });

        cards.forEach(card => observer.observe(card));
    });
</script>

</section>
<section class="video" id="video">
   <br><br>
    <div style="max-width:1100px;margin:0 auto 40px;">
     <iframe
        src="https://www.google.com/maps?q=36+Enterprise+Way+Riversgate+Sandown+Road+South+Africa&z=16&output=embed"
        width="100%"
        height="350"
        style="border:0;border-radius:8px;"
        allowfullscreen
        loading="lazy"
        referrerpolicy="no-referrer-when-downgrade">
    </iframe>

        <p style="text-align:center;margin-top:10px;">
         we are located at  📍 <strong>36 Enterprise way,Sandown Road, Cape Town, South Africa</strong>
        </p>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.Default', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\WEBSITES\mfmcapetown\resources\views/Home.blade.php ENDPATH**/ ?>