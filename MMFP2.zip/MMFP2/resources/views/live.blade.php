@vite(entrypoints: 'resources/css/app.css')
@vite(entrypoints: 'resources/js/app.js')
@vite(entrypoints: 'resources/css/about.css')
@extends('layouts.Default')

@section('content')
    <section class="Live">
       <h1> WATCH LIVE</h1>
    </section><br>
    
    <section class="frame">
        <center>
            <iframe width="85%" height="515"src="https://www.youtube.com/embed/live_stream?channel=UCSk7RAdJlgsbjlfrnM7efnA" frameborder="0" allowfullscreen>
  
            </iframe><br><br>
        </center>
        
        <script>
            var countDownDate = new Date("Dec 17, 2023 9:30:00").getTime();
            var x = setInterval(function() {
                var now = new Date().getTime();
                var distance = countDownDate - now;
                    
                var days = Math.floor(distance / (1000 * 60 * 60 * 24));
                var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
                var seconds = Math.floor((distance % (1000 * 60)) / 1000);
                    
                
                document.getElementById("demo").innerHTML = days + "d " + hours + "h "
                + minutes + "m " + seconds + "s ";
                    
                if (distance < 0) {
                    clearInterval(x);
                    document.getElementById("demo").innerHTML = "LIVE SERVICE HAS STARTED ";
                }

            }, 1000);
        </script><BR>
    </section>
@endsection