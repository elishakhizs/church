@vite(entrypoints: 'resources/css/app.css')
@vite(entrypoints: 'resources/js/app.js')
@vite(entrypoints: 'resources/css/about.css')
@extends('layouts.Default')

@section('content')
    <section class="givess">
        <h1>TITHE AND OFFERING </h1>
    </section>
      <div>
        <center><br><p style=" color:white"> GIVE</p> 
               <h3> Pay your offerings, tithes, first fruit offering etc via any of the listed platforms.
               </h3>
        </center>
      </div><br>
      <center>
        <a href="https://www.paypal.com/donate/?hosted_button_id=43MMV55U66DZQ">
            <img src="images/pay.jpg" width="400"hight="400" class="paypal">
        </a><br><br>
        <a href="https://www.paypal.com/donate/?hosted_button_id=43MMV55U66DZQ" class="button">Pay Here</a><br><br><br>
      </center>
    
    
     
@endsection