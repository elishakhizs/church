<?php

use Faker\Guesser\Name;
use Illuminate\Support\Facades\Route;


Route::get('/', function () {
    return view('Home');
});

Route::get('/home', function () {
    return redirect()->route('home');
});


Route::get('/about', function () {
    return view('about');
}) ->Name('about');

Route::get('/live', function () {
    return view('live');
}) ->Name('live');

Route::get('/Give', function () {
    return view('Give');
}) -> name('Give');
